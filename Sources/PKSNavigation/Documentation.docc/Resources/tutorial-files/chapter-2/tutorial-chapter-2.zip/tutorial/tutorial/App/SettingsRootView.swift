//
//  SettingsRootView.swift
//  tutorial
//
//  Created by Ömer Hamid Kamışlı on 10/7/24.
//

import SwiftUI
import PKSNavigation

struct SettingsRootView: View {
    @EnvironmentObject var navigationManager: PKSNavigationManager
    
    var body: some View {
        PKSNavigationContainer(navigationManager: navigationManager) {
            VStack {
                Image(systemName: "globe")
                    .imageScale(.large)
                    .foregroundStyle(.tint)
                Text("Settings Root View")
            }
            .padding()
        }
    }
}

#Preview {
    SettingsRootView()
        .environmentObject(PKSNavigationManager(identifier: "Settings Root Navigation Manager"))
}
