//
//  HomeRootView.swift
//  tutorial
//
//  Created by Ömer Hamid Kamışlı on 10/7/24.
//

import SwiftUI
import PKSNavigation

struct HomeRootView: View {
    @EnvironmentObject var navigationManager: PKSNavigationManager
    
    var body: some View {
        PKSNavigationContainer(navigationManager: navigationManager) {
            HomePage()
        }
    }
}

#Preview {
    HomeRootView()
        .environmentObject(PKSNavigationManager(identifier: "Home Root Navigation Manager"))
}
