//
//  tutorialApp.swift
//  tutorial
//
//  Created by Ömer Hamid Kamışlı on 10/6/24.
//

import SwiftUI

@main
struct tutorialApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .onAppear {
                    let appearance = UITabBarAppearance()
                    UITabBar.appearance().scrollEdgeAppearance = appearance
                }
        }
    }
}
